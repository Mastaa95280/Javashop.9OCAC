const grid = document.getElementById('grid');
const search = document.getElementById('search');
const category = document.getElementById('category');
const billing = document.getElementById('billing');

function formatPrice(price) {
  return new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(price);
}

function computedPrice(p) {
  if (billing.value === 'annuel') {
    return Math.round((p.price_eur_month * 12) * 0.9 * 100) / 100;
  } else {
    return p.price_eur_month;
  }
}

async function loadProducts() {
  const res = await fetch('products.json');
  const products = await res.json();
  render(products);
  [search, category, billing].forEach(el => el.addEventListener('input', () => render(products)));
}

function render(products) {
  const q = search.value.trim().toLowerCase();
  const cat = category.value;
  grid.innerHTML = '';
  products
    .filter(p => (cat ? p.category === cat : true))
    .filter(p => (q ? (p.name + ' ' + p.description + ' ' + p.features.join(' ')).toLowerCase().includes(q) : true))
    .forEach(p => {
      const price = computedPrice(p);
      const unit = billing.value === 'annuel' ? '/an' : '/mois';
      const payUrl = billing.value === 'annuel' ? (p.checkout_url_year || p.checkout_url) : p.checkout_url;
      const card = document.createElement('article');
      card.className = 'card';
      card.innerHTML = \`
        <div class="thumb">\${p.category}</div>
        <div class="body">
          <div class="badge">\${p.popular ? '⭐ Populaire' : 'Nouvelle offre'}</div>
          <h3>\${p.name}</h3>
          <div class="price">\${formatPrice(price)} <small>\${unit}</small></div>
          <p>\${p.description}</p>
          <ul>\${p.features.map(f => '<li>• ' + f + '</li>').join('')}</ul>
          <div class="actions">
            <a class="btn secondary" href="mailto:contact@mastaa-hosting.example?subject=Question%20sur%20' + encodeURIComponent(p.name) + '">Question</a>
            <a class="btn primary" href="\${payUrl}" target="_blank" rel="noopener">Acheter</a>
          </div>
        </div>
      \`;
      grid.appendChild(card);
    });
  document.getElementById('year').textContent = new Date().getFullYear();
}

loadProducts();
