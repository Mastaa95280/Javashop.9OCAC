# Boutique d’hébergement — GitHub Pages

Ce dépôt contient une boutique **statique** prête à déployer sur **GitHub Pages**. Parfait pour vendre des offres d’hébergement (mutualisé, VPS, dédiés) sans back‑end.

## 🚀 Déploiement rapide (5 minutes)

1. Créez un **nouveau dépôt** sur GitHub (ex: `mastaa-hosting`).
2. Uploadez tous les fichiers de ce dossier à la racine du dépôt.
3. Allez dans **Settings → Pages** et choisissez **Deploy from branch**, branch `main`, dossier `/ (root)`. Enregistrez.
4. Après le build, votre boutique sera disponible à l’URL donnée par GitHub Pages (ex: `https://<votre-user>.github.io/mastaa-hosting/`).

> Astuce: si vous nommez le dépôt `<votre-user>.github.io`, le site sera directement à la racine.

## 💳 Ajouter les paiements

- Remplacez les champs `checkout_url` (et `checkout_url_year`) dans `products.json` par vos liens **Stripe Payment Links** ou **PayPal** (Bouton PayPal → “Lien de paiement”).
- Option **e‑mail**: le bouton “Question” ouvre un mail prérempli. Vous pouvez remplacer l’adresse par la vôtre dans `app.js` et `index.html`.

## 🛍️ Gérer les produits

- Éditez `products.json` : chaque objet représente une offre.
- `price_eur_month` est le prix mensuel TTC. Le prix annuel appliquera **–10%** automatiquement.
- Les catégories reconnues: `Mutualisé`, `VPS`, `Dédié`, `Nom de domaine`. Vous pouvez en ajouter d’autres.

## 🖼️ Personnalisation

- Changez le logo dans `assets/logo.svg` et l’icône dans `assets/favicon.png`.
- Modifiez les couleurs/typos dans `style.css`.
- Le nom “javashop.9OCIC” se change dans `index.html` et `legal.html`.

## 📄 Légal & Contact

- Mettez à jour `legal.html` avec vos vraies mentions légales (SIREN/SIRET, adresse, éditeur, hébergeur).
- Mettez votre e‑mail/Discord dans `index.html` et `app.js`.

## 🧪 Test en local

Double‑cliquez `index.html` (ou servez via un serveur statique). Les fonctionnalités utilisent uniquement le navigateur.

---

Fait pour être simple, rapide et propre. Bonnes ventes !
